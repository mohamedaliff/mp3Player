﻿Public Class Genre
    Private Song_Genre_ID As Integer
    Private Genre_Name As String

    Public Property SongGenreID As Integer
        Get
            Return Song_Genre_ID
        End Get
        Set(value As Integer)
            Song_Genre_ID = value
        End Set
    End Property

    Public Property GenreName As String
        Get
            Return Genre_Name
        End Get
        Set(value As String)
            Genre_Name = value
        End Set
    End Property
End Class
