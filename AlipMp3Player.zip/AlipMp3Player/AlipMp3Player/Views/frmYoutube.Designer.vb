﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmYoutube
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.WB_YOUTUBE = New System.Windows.Forms.WebBrowser()
        Me.SuspendLayout()
        '
        'WB_YOUTUBE
        '
        Me.WB_YOUTUBE.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WB_YOUTUBE.Location = New System.Drawing.Point(0, 0)
        Me.WB_YOUTUBE.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WB_YOUTUBE.Name = "WB_YOUTUBE"
        Me.WB_YOUTUBE.Size = New System.Drawing.Size(800, 450)
        Me.WB_YOUTUBE.TabIndex = 0
        '
        'frmYoutube
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.WB_YOUTUBE)
        Me.Name = "frmYoutube"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Youtube MV"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents WB_YOUTUBE As WebBrowser
End Class
