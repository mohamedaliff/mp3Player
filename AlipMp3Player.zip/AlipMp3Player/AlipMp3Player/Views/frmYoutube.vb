﻿Public Class frmYoutube
    Private Sub frmYoutube_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            Dim source As String = frmMain.songLogic.songs.SongYoutubeURL

            Dim html As String = "<html><head>"
            html &= "<meta content='IE=Edge' http-equiv='X-UA-Compatible'/>"
            html &= "<iframe id='video' src= 'https://www.youtube.com/embed/{0}' width='100%' height='340' frameborder='0' allowfullscreen></iframe>"
            html &= "</body></html>"
            Me.WB_YOUTUBE.DocumentText = String.Format(html, source.Split("=")(1))


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

End Class