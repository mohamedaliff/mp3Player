﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManageGenre
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GRID_GENRE = New System.Windows.Forms.DataGridView()
        Me.GRP_CATEGORY = New System.Windows.Forms.GroupBox()
        Me.I_NAME = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.D_ID = New System.Windows.Forms.Label()
        Me.B_CLEAR = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.B_DELETE = New System.Windows.Forms.Button()
        Me.B_SUBMIT = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MENU_ADD = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.B_BACK = New System.Windows.Forms.Button()
        CType(Me.GRID_GENRE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GRP_CATEGORY.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GRID_GENRE
        '
        Me.GRID_GENRE.AllowUserToAddRows = False
        Me.GRID_GENRE.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        Me.GRID_GENRE.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.GRID_GENRE.BackgroundColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.GRID_GENRE.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.GRID_GENRE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.GRID_GENRE.DefaultCellStyle = DataGridViewCellStyle3
        Me.GRID_GENRE.Location = New System.Drawing.Point(12, 28)
        Me.GRID_GENRE.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GRID_GENRE.MultiSelect = False
        Me.GRID_GENRE.Name = "GRID_GENRE"
        Me.GRID_GENRE.ReadOnly = True
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Silver
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.GRID_GENRE.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.GRID_GENRE.RowHeadersWidth = 51
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.ControlDark
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black
        Me.GRID_GENRE.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.GRID_GENRE.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black
        Me.GRID_GENRE.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Poor Richard", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRID_GENRE.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White
        Me.GRID_GENRE.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Silver
        Me.GRID_GENRE.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.GRID_GENRE.RowTemplate.Height = 24
        Me.GRID_GENRE.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GRID_GENRE.ShowCellErrors = False
        Me.GRID_GENRE.ShowCellToolTips = False
        Me.GRID_GENRE.ShowEditingIcon = False
        Me.GRID_GENRE.ShowRowErrors = False
        Me.GRID_GENRE.Size = New System.Drawing.Size(426, 183)
        Me.GRID_GENRE.TabIndex = 26
        '
        'GRP_CATEGORY
        '
        Me.GRP_CATEGORY.Controls.Add(Me.I_NAME)
        Me.GRP_CATEGORY.Controls.Add(Me.Label1)
        Me.GRP_CATEGORY.Controls.Add(Me.D_ID)
        Me.GRP_CATEGORY.Controls.Add(Me.B_CLEAR)
        Me.GRP_CATEGORY.Controls.Add(Me.Label5)
        Me.GRP_CATEGORY.Controls.Add(Me.B_DELETE)
        Me.GRP_CATEGORY.Controls.Add(Me.B_SUBMIT)
        Me.GRP_CATEGORY.ForeColor = System.Drawing.Color.White
        Me.GRP_CATEGORY.Location = New System.Drawing.Point(12, 216)
        Me.GRP_CATEGORY.Name = "GRP_CATEGORY"
        Me.GRP_CATEGORY.Size = New System.Drawing.Size(320, 160)
        Me.GRP_CATEGORY.TabIndex = 24
        Me.GRP_CATEGORY.TabStop = False
        Me.GRP_CATEGORY.Text = "Edit Genre"
        '
        'I_NAME
        '
        Me.I_NAME.Location = New System.Drawing.Point(122, 66)
        Me.I_NAME.Name = "I_NAME"
        Me.I_NAME.Size = New System.Drawing.Size(190, 22)
        Me.I_NAME.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 17)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Name :"
        '
        'D_ID
        '
        Me.D_ID.AutoSize = True
        Me.D_ID.Location = New System.Drawing.Point(119, 35)
        Me.D_ID.Name = "D_ID"
        Me.D_ID.Size = New System.Drawing.Size(0, 17)
        Me.D_ID.TabIndex = 14
        '
        'B_CLEAR
        '
        Me.B_CLEAR.BackColor = System.Drawing.Color.Turquoise
        Me.B_CLEAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B_CLEAR.Location = New System.Drawing.Point(38, 104)
        Me.B_CLEAR.Name = "B_CLEAR"
        Me.B_CLEAR.Size = New System.Drawing.Size(88, 50)
        Me.B_CLEAR.TabIndex = 12
        Me.B_CLEAR.Text = "Clear"
        Me.B_CLEAR.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 35)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 17)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "ID :"
        '
        'B_DELETE
        '
        Me.B_DELETE.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.B_DELETE.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B_DELETE.Location = New System.Drawing.Point(130, 104)
        Me.B_DELETE.Name = "B_DELETE"
        Me.B_DELETE.Size = New System.Drawing.Size(88, 50)
        Me.B_DELETE.TabIndex = 7
        Me.B_DELETE.Text = "Delete"
        Me.B_DELETE.UseVisualStyleBackColor = False
        '
        'B_SUBMIT
        '
        Me.B_SUBMIT.BackColor = System.Drawing.Color.LimeGreen
        Me.B_SUBMIT.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B_SUBMIT.Location = New System.Drawing.Point(223, 104)
        Me.B_SUBMIT.Name = "B_SUBMIT"
        Me.B_SUBMIT.Size = New System.Drawing.Size(88, 50)
        Me.B_SUBMIT.TabIndex = 6
        Me.B_SUBMIT.Text = "Update"
        Me.B_SUBMIT.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Poor Richard", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.RefreshToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(448, 26)
        Me.MenuStrip1.TabIndex = 27
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MENU_ADD})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(54, 22)
        Me.ToolStripMenuItem1.Text = "Menu"
        '
        'MENU_ADD
        '
        Me.MENU_ADD.Name = "MENU_ADD"
        Me.MENU_ADD.Size = New System.Drawing.Size(176, 26)
        Me.MENU_ADD.Text = "Add new genre"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(66, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'B_BACK
        '
        Me.B_BACK.BackColor = System.Drawing.Color.Red
        Me.B_BACK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B_BACK.ForeColor = System.Drawing.Color.White
        Me.B_BACK.Location = New System.Drawing.Point(352, 320)
        Me.B_BACK.Name = "B_BACK"
        Me.B_BACK.Size = New System.Drawing.Size(88, 50)
        Me.B_BACK.TabIndex = 25
        Me.B_BACK.Text = "Close"
        Me.B_BACK.UseVisualStyleBackColor = False
        '
        'frmManageGenre
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(448, 379)
        Me.Controls.Add(Me.GRID_GENRE)
        Me.Controls.Add(Me.GRP_CATEGORY)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.B_BACK)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmManageGenre"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Manage Genre"
        CType(Me.GRID_GENRE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GRP_CATEGORY.ResumeLayout(False)
        Me.GRP_CATEGORY.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GRID_GENRE As DataGridView
    Friend WithEvents GRP_CATEGORY As GroupBox
    Friend WithEvents I_NAME As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents D_ID As Label
    Friend WithEvents B_CLEAR As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents B_DELETE As Button
    Friend WithEvents B_SUBMIT As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents MENU_ADD As ToolStripMenuItem
    Friend WithEvents B_BACK As Button
    Friend WithEvents RefreshToolStripMenuItem As ToolStripMenuItem
End Class
