﻿Public Class frmManageGenre

    Dim genreLogic As New GenreLogic

    Private Sub frmManageGenre_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshTable()
    End Sub

    Private Sub RefreshTable()
        Dim dataset1 As New System.Data.DataSet

        'Bind the value inside list of customer into gridview
        Dim source = New BindingSource(genreLogic.GetAllGenre(), Nothing)
        GRID_GENRE.DataSource = genreLogic.GetAllGenre()

        Dim block As Boolean = False

        dataset1.Clear()

        dataset1 = genreLogic.GetAllGenre()

        GRID_GENRE.DataSource = dataset1.Tables(0)
    End Sub

    Private Sub B_BACK_Click(sender As Object, e As EventArgs) Handles B_BACK.Click
        Me.Close()
    End Sub

    Private Sub B_CLEAR_Click(sender As Object, e As EventArgs) Handles B_CLEAR.Click
        Clear()
    End Sub

    Private Sub Clear()
        I_NAME.Text = ""
        D_ID.Text = ""
        I_NAME.Focus()
    End Sub

    Private Sub B_DELETE_Click(sender As Object, e As EventArgs) Handles B_DELETE.Click
        Try

            If (D_ID.Text.Trim = "") Then
                MessageBox.Show("No genre selected")
                I_NAME.Focus()
            Else

                If CBool((Me.genreLogic.DeleteGenre(CInt(D_ID.Text.Trim)))) Then
                    MessageBox.Show("Genre deleted")
                    Clear()
                    RefreshTable()
                Else
                    MessageBox.Show("Delete failed")
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub B_SUBMIT_Click(sender As Object, e As EventArgs) Handles B_SUBMIT.Click
        If (I_NAME.Text.Trim = "") Then
            MessageBox.Show("Textbox empty")
            I_NAME.Focus()
        Else
            genreLogic.genres.GenreName = I_NAME.Text

            If (D_ID.Text.Trim = "") Then
                MessageBox.Show("No item selected")
                I_NAME.Focus()
                Exit Sub
            End If

            If CBool((Me.genreLogic.UpdateGenre(CInt(D_ID.Text.Trim)))) Then
                MessageBox.Show("Genre updated")
                Clear()
                RefreshTable()
            Else
                MessageBox.Show("Update failed")
            End If
        End If
    End Sub

    Private Sub GRID_GENRE_SelectionChanged(sender As Object, e As EventArgs) Handles GRID_GENRE.SelectionChanged
        Try

            Dim rowsCount As Integer = GRID_GENRE.SelectedRows.Count

            If (rowsCount = 0 Or rowsCount > 1) Then
                Return
            End If

            Dim selGenreD As Integer

            selGenreD = GRID_GENRE.SelectedRows(0).Cells(0).Value

            If (selGenreD > 0) Then

                'Me.categoryLogic.GetCategoryById(selCategoryID)
                Dim genres As Genre = Me.genreLogic.GetGenreById(selGenreD)

                I_NAME.Text = genres.GenreName
                D_ID.Text = genres.SongGenreID

            End If


        Catch ex As Exception
            MessageBox.Show(ex.ToString, "Exception Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
        End Try
    End Sub

    Private Sub MENU_ADD_Click(sender As Object, e As EventArgs) Handles MENU_ADD.Click
        Dim frmAddGenre As New frmAddGenre
        frmAddGenre.ShowDialog()
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        RefreshTable()
    End Sub
End Class