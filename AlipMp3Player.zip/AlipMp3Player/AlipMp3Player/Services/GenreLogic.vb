﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class GenreLogic

    Public genres As New Genre
    Public configs As New Config
    Dim constr = configs.constr

    ''' <summary>
    ''' This function is used to insert song genre data into database during add new process
    ''' </summary>
    ''' <returns></returns>
    Public Function InsertSongGenre() As Boolean

        Dim InsertQuery = "INSERT INTO TBL_SONG_GENRE " _
            & "(GENRE_NAME) " _
            & "VALUES " _
            & "(@genre_name)"

        Using con As SqlConnection = New SqlConnection(constr)
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand(InsertQuery, con)

            cmd.Parameters.Add("@genre_name", SqlDbType.VarChar).Value = genres.GenreName.ToString

            Dim recordsAffected As Integer = cmd.ExecuteNonQuery()

            If recordsAffected > 0 Then
                Return True
            Else
                Return False
            End If

            con.Close()

        End Using
    End Function

    ''' <summary>
    ''' This function is to get list of genres from database and set into dataset
    ''' </summary>
    Public Function GetAllGenre() As DataSet

        Dim da As New System.Data.SqlClient.SqlDataAdapter
        Dim ds As New DataSet

        Try
            Using con = New SqlConnection(constr)
                con.Open()

                Dim selQuery As String = "SELECT * FROM TBL_SONG_GENRE"

                Dim sqlcmd As New SqlCommand(selQuery, con)
                sqlcmd.CommandTimeout = 0
                da.SelectCommand = sqlcmd
                da.Fill(ds)

                Return ds
            End Using
        Catch ex As Exception
            Return ds
        Finally

        End Try

    End Function

    ''' <summary>
    ''' This function is to get list of genres from database and set into combobox
    ''' </summary>
    ''' <param name="cb"></param>
    Public Sub GetGenreList(ByVal cb As ComboBox)

        Dim selQuery As String = "SELECT * FROM TBL_SONG_GENRE"


        Using con As SqlConnection = New SqlConnection(constr) 'Declare new connection
            con.Open() 'Open connection

            Using da As New SqlDataAdapter(selQuery, con)

                Dim dt As DataTable = New DataTable()

                cb.ValueMember = "GENRE_ID"
                cb.DisplayMember = "GENRE_NAME"

                'Bind the value inside list of category into drop down list
                da.Fill(dt)
                cb.DataSource = dt

            End Using

            cb.Text = "All Genre"
            cb.SelectedIndex = -1

            con.Close()

        End Using

    End Sub

    Public Function GetGenreById(ByVal GenreID As String) As Genre

        Dim selQuery As String = "SELECT * FROM TBL_SONG_GENRE WHERE GENRE_ID = @genre_id"

        Dim item As New Genre()

        Using con As SqlConnection = New SqlConnection(constr)
            con.Open()

            Dim cmd As SqlCommand = New SqlCommand(selQuery, con)

            cmd.Parameters.Add("@genre_id", SqlDbType.Int).Value = CInt(GenreID)

            Using dr As SqlDataReader = cmd.ExecuteReader()
                If dr.Read() Then

                    'Set data from database into object property

                    item.SongGenreID = CInt(dr("GENRE_ID"))
                    item.GenreName = CType(dr("GENRE_NAME"), String)

                End If
            End Using

            con.Close()

        End Using

        Return item

    End Function


    ''' <summary>
    ''' This function is to delete genre by ID selected
    ''' </summary>
    ''' <param name="GenreID"></param>
    ''' <returns></returns>
    Public Function DeleteGenre(ByVal GenreID As Integer) As Boolean

        Dim delQuery = "DELETE FROM TBL_SONG_GENRE WHERE GENRE_ID=@genre_id "

        Using con As SqlConnection = New SqlConnection(constr)
            con.Open()

            Dim cmd As SqlCommand = New SqlCommand(delQuery, con)

            cmd.Parameters.AddWithValue("@genre_id", GenreID)

            Dim recordsAffected As Integer = cmd.ExecuteNonQuery()

            If recordsAffected > 0 Then
                genres.SongGenreID = 0 'Remove SONG_ID object property
                Return True
            Else
                Return False
            End If

            con.Close()

        End Using

    End Function


    ''' <summary>
    ''' This function is used to update genre data in the database during detail update process
    ''' </summary>
    ''' <returns></returns>
    Public Function UpdateGenre(ByVal GenreID As Integer) As Boolean

        Dim updateQuery = "UPDATE TBL_SONG_GENRE " _
            & "Set  GENRE_NAME= @genre_name" _
            & " WHERE GENRE_ID= @genre_id"

        Using con As SqlConnection = New SqlConnection(constr)
            con.Open()

            Dim cmd As SqlCommand = New SqlCommand(updateQuery, con)

            cmd.Parameters.Add("@genre_name", SqlDbType.VarChar).Value = genres.GenreName.ToString

            cmd.Parameters.AddWithValue("@genre_id", GenreID)

            Dim recordsAffected As Integer = cmd.ExecuteNonQuery()

            If recordsAffected > 0 Then
                Return True
            Else
                Return False
            End If

            con.Close()
        End Using

    End Function

End Class
