﻿Imports System.Configuration

Public Class Config

    Public constr As String = ConfigurationManager.ConnectionStrings("ConnectionString").ToString()

End Class
